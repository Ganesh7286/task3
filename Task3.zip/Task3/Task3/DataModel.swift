//
//  DataModel.swift
//  Task3
//
//  Created by sravan yadav on 22/05/24.
//

import UIKit

class DataModel: NSObject,Decodable {
    public var Id : String?
    public var Name : String?
    public var ArabicName : String?
    public var Description : String?
    public var ContactNo : String?
    public var ArabicContactNo : String?
    public var Picture : String?
    public var Sunday : String?
    public var Monday : String?
    public var Tuesday : String?
    public var Wednesday : String?
    public var Thursday : String?
    public var Friday : String?
    public var Saturday : String?
    public var doctor_hospital : String?
    public var Hospital : String?
    public var HospitalArabicName : String?
    public var HospitalLatitude : String?
    public var HospitalLongitude : String?
    public var HospitalCity : String?
    public var HospitalArabicCity : String?
    public var doctor_specialization : String?
    public var Specialization : String?
    public var SpecializationArabicTitle : String?
    public var doctor_department : String?
    public var Department : String?
    public var DepartmentArabicTitle : String?
    public var DoctorRating : String?
    public var Disabled : String?
    
    enum ColorcodeKeys : String,CodingKey{
        case Id = "Id"
        case Name = "Name"
        case ArabicName = "ArabicName"
        case Description = "Description"
        case ContactNo = "ContactNo"
        case ArabicContactNo = "ArabicContactNo"
        case Picture = "Picture"
        case Sunday = "Sunday"
        case Monday = "Monday"
        case Tuesday = "Tuesday"
        case Wednesday = "Wednesday"
        case Thursday = "Thursday"
        case Friday = "Friday"
        case Saturday = "Saturday"
        case doctor_hospital = "doctor_hospital"
        case Hospital = "Hospital"
        case HospitalArabicName = "HospitalArabicName"
        case HospitalLatitude = "HospitalLatitude"
        case HospitalLongitude = "HospitalLongitude"
        case HospitalCity = "HospitalCity"
        case HospitalArabicCity = "HospitalArabicCity"
        case doctor_specialization = "doctor_specialization"
        case Specialization = "Specialization"
        case SpecializationArabicTitle = "SpecializationArabicTitle"
        case doctor_department = "doctor_department"
        case Department = "Department"
        case DepartmentArabicTitle = "DepartmentArabicTitle"
        case DoctorRating = "DoctorRating"
        case Disabled = "Disabled"
        
    }
    public override init() {
        super.init()
    }
    required public init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: ColorcodeKeys.self)
        Id = try? container.decode(String.self, forKey: .Id)
        Name = try? container.decode(String.self, forKey: .Name)
        ArabicName = try? container.decode(String.self, forKey: .ArabicName)
        Description = try? container.decode(String.self, forKey: .Description)
        ContactNo = try? container.decode(String.self, forKey: .ContactNo)
        ArabicContactNo = try? container.decode(String.self, forKey: .ArabicContactNo)
        Picture = try? container.decode(String.self, forKey: .Picture)
        Sunday = try? container.decode(String.self, forKey: .Sunday)
        Monday = try? container.decode(String.self, forKey: .Monday)
        Tuesday = try? container.decode(String.self, forKey: .Tuesday)
        Wednesday = try? container.decode(String.self, forKey: .Wednesday)
        Thursday = try? container.decode(String.self, forKey: .Thursday)
        Friday = try? container.decode(String.self, forKey: .Friday)
        Saturday = try? container.decode(String.self, forKey: .Saturday)
        doctor_hospital = try? container.decode(String.self, forKey: .doctor_hospital)
        Hospital = try? container.decode(String.self, forKey: .Hospital)
        HospitalArabicName = try? container.decode(String.self, forKey: .HospitalArabicName)
        HospitalLatitude = try? container.decode(String.self, forKey: .HospitalLatitude)
        HospitalLongitude = try? container.decode(String.self, forKey: .HospitalLongitude)
        HospitalCity = try? container.decode(String.self, forKey: .HospitalCity)
        HospitalArabicCity = try? container.decode(String.self, forKey: .HospitalArabicCity)
        HospitalLatitude = try? container.decode(String.self, forKey: .HospitalLatitude)
        doctor_specialization = try? container.decode(String.self, forKey: .doctor_specialization)
        Specialization = try? container.decode(String.self, forKey: .Specialization)
        SpecializationArabicTitle = try? container.decode(String.self, forKey: .SpecializationArabicTitle)
        doctor_department = try? container.decode(String.self, forKey: .doctor_department)
        Department = try? container.decode(String.self, forKey: .Department)
        DepartmentArabicTitle = try? container.decode(String.self, forKey: .DepartmentArabicTitle)
        DoctorRating = try? container.decode(String.self, forKey: .DoctorRating)
        Department = try? container.decode(String.self, forKey: .Department)
        Disabled = try? container.decode(String.self, forKey: .Disabled)
        
        
    }
}
